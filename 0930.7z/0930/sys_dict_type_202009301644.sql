INSERT INTO goadmin.sys_dict_type (dict_name,dict_type,status,create_by,update_by,remark,created_at,updated_at,deleted_at) VALUES 
('系统开关','sys_normal_disable','0','1','1','系统开关列表','2020-04-11 15:52:48.0',NULL,NULL)
,('用户性别','sys_user_sex','0','1','','用户性别列表','2020-04-11 15:52:48.0',NULL,NULL)
,('菜单状态','sys_show_hide','0','1','','菜单状态列表','2020-04-11 15:52:48.0',NULL,NULL)
,('系统是否','sys_yes_no','0','1','','系统是否列表','2020-04-11 15:52:48.0',NULL,NULL)
,('任务状态','sys_job_status','0','1','','任务状态列表','2020-04-11 15:52:48.0',NULL,NULL)
,('任务分组','sys_job_group','0','1','','任务分组列表','2020-04-11 15:52:48.0',NULL,NULL)
,('通知类型','sys_notice_type','0','1','','通知类型列表','2020-04-11 15:52:48.0',NULL,NULL)
,('系统状态','sys_common_status','0','1','','登录状态列表','2020-04-11 15:52:48.0',NULL,NULL)
,('操作类型','sys_oper_type','0','1','','操作类型列表','2020-04-11 15:52:48.0',NULL,NULL)
,('通知状态','sys_notice_status','0','1','','通知状态列表','2020-04-11 15:52:48.0',NULL,NULL)
;