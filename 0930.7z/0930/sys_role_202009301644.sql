INSERT INTO goadmin.sys_role (role_name,status,role_key,role_sort,flag,create_by,update_by,remark,admin,data_scope,created_at,updated_at,deleted_at) VALUES 
('系统管理员','0','admin',1,NULL,'1',NULL,NULL,0,NULL,'2020-04-11 15:52:48.0','2020-09-29 13:12:56.0',NULL)
,('普通角色','0','common',2,NULL,'1',NULL,NULL,0,'2','2020-04-11 15:52:48.0','2020-05-03 21:32:59.0',NULL)
,('测试角色','0','Tester',3,'','1',NULL,NULL,0,NULL,'2020-04-11 15:52:48.0','2020-04-12 14:10:52.0',NULL)
;