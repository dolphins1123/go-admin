INSERT INTO goadmin.sys_config (config_name,config_key,config_value,config_type,remark,create_by,update_by,created_at,updated_at,deleted_at) VALUES 
('主框架页-默认皮肤样式名称','sys_index_skinName','skin-blue','Y','蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow','1','1','2020-02-29 10:37:48.0','2020-04-08 13:03:21.0',NULL)
,('用户管理-账号初始密码','sys.user.initPassword','123456','Y','初始化密码 123456','1','1','2020-02-29 10:38:23.0','2020-03-11 00:35:28.0',NULL)
,('主框架页-侧边栏主题','sys_index_sideTheme','theme-dark','Y','深色主题theme-dark，浅色主题theme-light','1','1','2020-02-29 10:39:01.0','2020-04-07 23:21:50.0',NULL)
;