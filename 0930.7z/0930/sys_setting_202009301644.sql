INSERT INTO goadmin.sys_setting (name,logo,created_at,updated_at,deleted_at) VALUES 
('go-admin管理系统','http://127.0.0.1:8000/static/uploadfile/e61e95de-c356-4fe7-bda2-d6e49b246545.jpg','2020-08-05 14:27:34.0','2020-09-30 13:58:41.0',NULL)
;