INSERT INTO goadmin.article (title,author,content,status,publish_at,created_at,updated_at,deleted_at,create_by,update_by) VALUES 
('test','222222','222',1,'2020-09-29 10:54:06.0','2020-09-28 09:43:29.0','2020-09-28 11:57:04.0',NULL,1,1)
,('XXXXXX','XXXXXXX','XXXXXX',0,'2020-09-28 12:57:56.0','2020-09-28 09:50:39.0','2020-09-28 11:55:17.0',NULL,1,1)
;