INSERT INTO goadmin.sys_job (job_name,job_group,job_type,cron_expression,invoke_target,misfire_policy,concurrent,status,entry_id,create_by,update_by,created_at,updated_at,deleted_at) VALUES 
('接口测试','DEFAULT',1,'0/5 * * * * ?','http://localhost:8000',1,1,2,0,'','','2020-08-03 14:54:03.0','2020-09-30 08:33:53.0',NULL)
,('函数测试','DEFAULT',2,'0/5 * * * * ?','ExamplesOne',1,1,2,0,'','','2020-08-11 21:41:23.0','2020-09-30 08:33:53.0',NULL)
;