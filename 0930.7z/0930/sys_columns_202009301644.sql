INSERT INTO goadmin.sys_columns (table_id,column_name,column_comment,column_type,go_type,go_field,json_field,is_pk,is_increment,is_required,is_insert,is_edit,is_list,is_query,query_type,html_type,dict_type,sort,list,pk,required,super_column,usable_column,`increment`,`insert`,edit,query,remark,create_by,update_By,created_at,updated_at,deleted_at) VALUES 
(1,'id','编码','int(11)','int','Id','id','1','','1','1','','','','EQ','input','',1,'',1,1,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'title','标题','varchar(128)','string','Title','title','0','','0','1','1','1','1','LIKE','input','',2,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'author','作者','varchar(128)','string','Author','author','0','','0','1','1','1','1','EQ','input','',3,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'content','内容','varchar(255)','string','Content','content','0','','0','1','1','','','EQ','input','',4,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'status','状态','int','int64','Status','status','0','','0','1','1','1','','EQ','radio','sys_show_hide',5,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'publish_at','发布时间','timestamp','time.Time','PublishAt','publishAt','0','','0','1','1','1','','EQ','datetime','',6,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'created_at','','timestamp','time.Time','CreatedAt','createdAt','0','','0','1','','','','EQ','datetime','',7,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'updated_at','','timestamp','time.Time','UpdatedAt','updatedAt','0','','0','1','','','','EQ','datetime','',8,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'deleted_at','','timestamp','time.Time','DeletedAt','deletedAt','0','','0','1','','','','EQ','datetime','',9,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(1,'create_by','','int(11)','string','CreateBy','createBy','0','','0','1','','','','EQ','input','',10,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
;
INSERT INTO goadmin.sys_columns (table_id,column_name,column_comment,column_type,go_type,go_field,json_field,is_pk,is_increment,is_required,is_insert,is_edit,is_list,is_query,query_type,html_type,dict_type,sort,list,pk,required,super_column,usable_column,`increment`,`insert`,edit,query,remark,create_by,update_By,created_at,updated_at,deleted_at) VALUES 
(1,'update_by','','int(11)','string','UpdateBy','updateBy','0','','0','1','','','','EQ','input','',11,'',0,0,0,0,0,1,0,0,'','','','2020-09-28 09:41:54.0','2020-09-28 11:56:35.0',NULL)
,(4,'id','id','int(11)','int','Id','id','1','','1','1','','1','','EQ','input','',1,'',1,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'input1','輸入框','varchar(20)','string','Input1','input1','0','','1','1','1','1','1','EQ','input','',2,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'number1','計數器','int(11)','string','Number1','number1','0','','1','1','1','1','0','EQ','input','',3,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'select1','下拉選項1','varchar(20)','string','Select1','select1','0','','1','1','1','0','0','EQ','input','',4,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'select2','下拉多選','varchar(50)','string','Select2','select2','0','','1','1','','','','EQ','input','',5,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'select3s','下拉多選1','varchar(50)','string','Select3s','select3s','0','','1','1','','','','EQ','input','',6,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'select3m','Cascader级联选择器','varchar(100)','string','Select3m','select3m','0','','1','1','','','','EQ','input','',7,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'switch1','Switch开关','varchar(1)','string','Switch1','switch1','0','','1','1','','','','EQ','input','',8,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'datepicker1','DatePicker','timestamp','time.Time','Datepicker1','datepicker1','0','','1','1','','','','EQ','datetime','',9,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
;
INSERT INTO goadmin.sys_columns (table_id,column_name,column_comment,column_type,go_type,go_field,json_field,is_pk,is_increment,is_required,is_insert,is_edit,is_list,is_query,query_type,html_type,dict_type,sort,list,pk,required,super_column,usable_column,`increment`,`insert`,edit,query,remark,create_by,update_By,created_at,updated_at,deleted_at) VALUES 
(4,'timepicker1','timepicker1','time','string','Timepicker1','timepicker1','0','','1','1','','','','EQ','input','',10,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'upload1','Upload 上传','varchar(100)','string','Upload1','upload1','0','','1','1','','','','EQ','input','',11,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'tansfer1','Transfer','varchar(100)','string','Tansfer1','tansfer1','0','','1','1','','','','EQ','input','',12,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'createBy','','varchar(20)','string','CreateBy','createBy','0','','1','1','','','','EQ','input','',13,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(4,'updateBy','','varchar(20)','string','UpdateBy','updateBy','0','','1','1','','','','EQ','input','',14,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 11:29:02.0','2020-09-29 11:48:36.0',NULL)
,(6,'id','id','int(11)','int','Id','id','1','','1','1','','','','EQ','input','',1,'',1,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'input1','輸入框','varchar(20)','string','Input1','input1','0','','1','1','1','1','1','EQ','input','',2,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'number1','計數器','int(11)','int64','Number1','number1','0','','1','1','1','1','','EQ','input','',3,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'select1','下拉選項1','varchar(20)','string','Select1','select1','0','','1','1','1','1','','EQ','select','sys_job_group',4,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'select2','下拉多選','varchar(50)','string','Select2','select2','0','','1','1','','','','EQ','input','',5,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
;
INSERT INTO goadmin.sys_columns (table_id,column_name,column_comment,column_type,go_type,go_field,json_field,is_pk,is_increment,is_required,is_insert,is_edit,is_list,is_query,query_type,html_type,dict_type,sort,list,pk,required,super_column,usable_column,`increment`,`insert`,edit,query,remark,create_by,update_By,created_at,updated_at,deleted_at) VALUES 
(6,'select3s','下拉多選1','varchar(50)','string','Select3s','select3s','0','','1','1','','','','EQ','input','',6,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'select3m','Cascader级联选择器','varchar(100)','string','Select3m','select3m','0','','1','1','','','','EQ','input','',7,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'switch1','Switch开关','varchar(1)','string','Switch1','switch1','0','','1','1','','','','EQ','input','',8,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'datepicker1','DatePicker','timestamp','time.Time','Datepicker1','datepicker1','0','','1','1','','','','EQ','datetime','',9,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'timepicker1','timepicker1','time','string','Timepicker1','timepicker1','0','','1','1','','','','EQ','input','',10,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'upload1','Upload 上传','varchar(100)','string','Upload1','upload1','0','','1','1','','','','EQ','input','',11,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'tansfer1','Transfer','varchar(100)','string','Tansfer1','tansfer1','0','','1','1','','','','EQ','input','',12,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'create_by','','varchar(20)','string','CreateBy','createBy','0','','1','1','','','','EQ','input','',13,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'update_by','','varchar(20)','string','UpdateBy','updateBy','0','','1','1','','','','EQ','input','',14,'',0,1,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'created_at','','timestamp','time.Time','CreatedAt','createdAt','0','','0','1','','','','EQ','datetime','',15,'',0,0,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
;
INSERT INTO goadmin.sys_columns (table_id,column_name,column_comment,column_type,go_type,go_field,json_field,is_pk,is_increment,is_required,is_insert,is_edit,is_list,is_query,query_type,html_type,dict_type,sort,list,pk,required,super_column,usable_column,`increment`,`insert`,edit,query,remark,create_by,update_By,created_at,updated_at,deleted_at) VALUES 
(6,'updated_at','','timestamp','time.Time','UpdatedAt','updatedAt','0','','0','1','','','','EQ','datetime','',16,'',0,0,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
,(6,'deleted_at','','timestamp','time.Time','DeletedAt','deletedAt','0','','0','1','','','','EQ','datetime','',17,'',0,0,0,0,0,1,0,0,'','','','2020-09-29 13:12:18.0','2020-09-29 13:39:56.0',NULL)
;