INSERT INTO goadmin.sys_post (post_name,post_code,sort,status,remark,create_by,update_by,created_at,updated_at,deleted_at) VALUES 
('首席执行官','CEO',0,'0','首席执行官','1','2020-03-08 23:11:15','2020-04-11 15:52:48.0',NULL,NULL)
,('首席技术执行官','CTO',2,'0','首席技术执行官','1','1','2020-04-11 15:52:48.0','2020-05-03 20:58:01.0',NULL)
,('首席运营官','COO',3,'0','测试工程师','1','1','2020-04-11 15:52:48.0',NULL,NULL)
;